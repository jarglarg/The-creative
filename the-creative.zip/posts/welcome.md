---
title: "Welcome to The Creative"
date: 2025-07-05
category: News
---

This is your first blog post. Edit or delete it from the CMS.